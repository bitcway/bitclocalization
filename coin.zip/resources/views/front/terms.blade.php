@extends('front.layouts.main')

@section('custom_css')

@endsection

@section('content')


<div id="home">
    <div class="mt-5">
        <h3>Terms</h3>
        <hr>
        <p>
            <h4>Lorem ipsum dolor sit</h4>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod nulla voluptatem illo in possimus enim sit neque. Doloribus temporibus voluptates corporis molestiae, ullam velit, odit perspiciatis nostrum corrupti placeat repudiandae vitae ut quod incidunt blanditiis perferendis iusto autem! Nostrum atque facilis reiciendis et animi culpa exercitationem voluptatibus ratione repudiandae autem ducimus obcaecati in illum, iusto laboriosam iste fugit quisquam. Alias inventore consequatur ipsa. Sed, modi. Optio quis error sit a explicabo odit illo minima assumenda rem asperiores eveniet, perspiciatis provident. Debitis asperiores labore tenetur nemo numquam, voluptate corporis? Fugiat voluptatibus facere in autem sunt nemo iste officiis quia non sequi itaque vero, ipsam culpa nihil quasi accusamus asperiores aspernatur! Repellendus laborum iste numquam minima, commodi iure, voluptatum quibusdam cupiditate enim facilis nihil est 
        </p>
        <p>
            <h4>Lorem ipsum dolor sit</h4>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod nulla voluptatem illo in possimus enim sit neque. Doloribus temporibus voluptates corporis molestiae, ullam velit, odit perspiciatis nostrum corrupti placeat repudiandae vitae ut quod incidunt blanditiis perferendis iusto autem! Nostrum atque facilis reiciendis et animi culpa exercitationem voluptatibus ratione repudiandae autem ducimus obcaecati in illum, iusto laboriosam iste fugit quisquam. Alias inventore consequatur ipsa. Sed, modi. Optio quis error sit a explicabo odit illo minima assumenda rem asperiores eveniet, perspiciatis provident. Debitis asperiores labore tenetur nemo numquam, voluptate corporis? Fugiat voluptatibus facere in autem sunt nemo iste officiis quia non sequi itaque vero, ipsam culpa nihil quasi accusamus asperiores aspernatur! Repellendus laborum iste numquam minima, commodi iure, voluptatum quibusdam cupiditate enim facilis nihil est 
        </p>
        <p>
            <h4>Lorem ipsum dolor sit</h4>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod nulla voluptatem illo in possimus enim sit neque. Doloribus temporibus voluptates corporis molestiae, ullam velit, odit perspiciatis nostrum corrupti placeat repudiandae vitae ut quod incidunt blanditiis perferendis iusto autem! Nostrum atque facilis reiciendis et animi culpa exercitationem voluptatibus ratione repudiandae autem ducimus obcaecati in illum, iusto laboriosam iste fugit quisquam. Alias inventore consequatur ipsa. Sed, modi. Optio quis error sit a explicabo odit illo minima assumenda rem asperiores eveniet, perspiciatis provident. Debitis asperiores labore tenetur nemo numquam, voluptate corporis? Fugiat voluptatibus facere in autem sunt nemo iste officiis quia non sequi itaque vero, ipsam culpa nihil quasi accusamus asperiores aspernatur! Repellendus laborum iste numquam minima, commodi iure, voluptatum quibusdam cupiditate enim facilis nihil est 
        </p>
        <p>
            <h4>Lorem ipsum dolor sit</h4>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod nulla voluptatem illo in possimus enim sit neque. Doloribus temporibus voluptates corporis molestiae, ullam velit, odit perspiciatis nostrum corrupti placeat repudiandae vitae ut quod incidunt blanditiis perferendis iusto autem! Nostrum atque facilis reiciendis et animi culpa exercitationem voluptatibus ratione repudiandae autem ducimus obcaecati in illum, iusto laboriosam iste fugit quisquam. Alias inventore consequatur ipsa. Sed, modi. Optio quis error sit a explicabo odit illo minima assumenda rem asperiores eveniet, perspiciatis provident. Debitis asperiores labore tenetur nemo numquam, voluptate corporis? Fugiat voluptatibus facere in autem sunt nemo iste officiis quia non sequi itaque vero, ipsam culpa nihil quasi accusamus asperiores aspernatur! Repellendus laborum iste numquam minima, commodi iure, voluptatum quibusdam cupiditate enim facilis nihil est 
        </p>
        <p>
            <h4>Lorem ipsum dolor sit</h4>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod nulla voluptatem illo in possimus enim sit neque. Doloribus temporibus voluptates corporis molestiae, ullam velit, odit perspiciatis nostrum corrupti placeat repudiandae vitae ut quod incidunt blanditiis perferendis iusto autem! Nostrum atque facilis reiciendis et animi culpa exercitationem voluptatibus ratione repudiandae autem ducimus obcaecati in illum, iusto laboriosam iste fugit quisquam. Alias inventore consequatur ipsa. Sed, modi. Optio quis error sit a explicabo odit illo minima assumenda rem asperiores eveniet, perspiciatis provident. Debitis asperiores labore tenetur nemo numquam, voluptate corporis? Fugiat voluptatibus facere in autem sunt nemo iste officiis quia non sequi itaque vero, ipsam culpa nihil quasi accusamus asperiores aspernatur! Repellendus laborum iste numquam minima, commodi iure, voluptatum quibusdam cupiditate enim facilis nihil est 
        </p>
        <p>
            <h4>Lorem ipsum dolor sit</h4>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod nulla voluptatem illo in possimus enim sit neque. Doloribus temporibus voluptates corporis molestiae, ullam velit, odit perspiciatis nostrum corrupti placeat repudiandae vitae ut quod incidunt blanditiis perferendis iusto autem! Nostrum atque facilis reiciendis et animi culpa exercitationem voluptatibus ratione repudiandae autem ducimus obcaecati in illum, iusto laboriosam iste fugit quisquam. Alias inventore consequatur ipsa. Sed, modi. Optio quis error sit a explicabo odit illo minima assumenda rem asperiores eveniet, perspiciatis provident. Debitis asperiores labore tenetur nemo numquam, voluptate corporis? Fugiat voluptatibus facere in autem sunt nemo iste officiis quia non sequi itaque vero, ipsam culpa nihil quasi accusamus asperiores aspernatur! Repellendus laborum iste numquam minima, commodi iure, voluptatum quibusdam cupiditate enim facilis nihil est 
        </p>
    </div>

</div>
@endsection

@section('custom_js')
@endsection
