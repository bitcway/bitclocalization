import { BaseUpload } from 'craftable';

Vue.component('media-upload', {
    mixins: [BaseUpload]
});