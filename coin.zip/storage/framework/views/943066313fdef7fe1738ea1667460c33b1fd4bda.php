<?php $__env->startSection('custom_css'); ?>
<style>
    .item{
        width: 100%;
        display: block;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div id="wrap">
    <h2>Message List</h2>
    <hr>
    <div class="card">
        <div class="card-body">
            <ul class="list-group">
                <?php foreach($messages as $item){?>
                <a class="item" href="<?php echo e(route('admin-message-details', ['to_id' => $item->user_id])); ?>">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        
                            <span>
                                <?php echo e($item->user->first_name.' '.$item->user->last_name); ?> at <?php echo e(date('d/m/Y H:i', strtotime($item->created_at))); ?>

                                <br>
                                <small><?php echo e($item->latestMessage()->message); ?></small>
                            </span>

                            <span class="badge bg-primary pill"><?php echo e($item->unread()); ?></span>
                        
                    </li>
                </a>
                <?php }?>
            </ul>
        </div>
    </div>
    
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script type="text/javascript">
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/coin_client/resources/views/admin/message/index.blade.php ENDPATH**/ ?>