<?php $__env->startSection('custom_css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="wrap" class="deposit">
    <h2>Assets</h2>
    <hr>
    <div class="card">
        <div class="card-body text-center">
            <h4>Equivalent Asset Amount:  <?php echo e($total); ?> USDT</h4>
        </div>
    </div>
    <div class="card mt-3">
        <div class="card-body">
            <div class="text-center"><h4>Asset Breakdown</h4></div>
            

            <ul class="list-group col-md-6 offset-md-3">
                <?php foreach($wallets as $item){?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <?php echo e($item->currency->name); ?>

                    <span class="badge bg-primary pill"><?php echo e($item->balance); ?></span>
                </li>
                <?php }?>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/coin_client/resources/views/admin/user/wallets.blade.php ENDPATH**/ ?>