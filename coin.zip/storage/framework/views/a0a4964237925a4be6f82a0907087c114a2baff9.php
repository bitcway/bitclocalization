<?php $__env->startSection('custom_css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div id="wrap">
    <h2>Buy/Sell</h2>
    <hr>
    <div class="card">
        <div class="card-body">
            <table class="table">
                <thead>
                    <th>Date</th>
                    <th>Coin</th>
                    <th>Amount</th>
                    <th>Equivalent Amount (USDT)</th>
                    <th>Type</th>
                </thead>
                <tbody>
                    <?php foreach($transactions as $item){?>
                    <tr>
                        <td><?php echo e(date('d/m/Y H:i', strtotime($item->created_at))); ?></td>
                        <td><?php echo e($item->currency->name); ?></td>
                        <td><?php echo e($item->amount); ?></td>
                        <td><?php echo e($item->equivalent_amount); ?></td>
                        <td>
                            <?php echo e($item->type==1?'Buy':'Sell'); ?>

                        </td>
                    </tr>
                    <?php }?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/coin_client/resources/views/user/buysell/index.blade.php ENDPATH**/ ?>