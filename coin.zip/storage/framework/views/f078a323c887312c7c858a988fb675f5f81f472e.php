<?php if(session('message')): ?>
<div class="alert alert-primary alert-dismissible fade show mb-3" role="alert">
    <?php echo e(session('message')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session('secondary_message')): ?>
<div class="alert alert-secondary alert-dismissible fade show mb-3" role="alert">
    <?php echo e(session('secondary_message')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session('success_message')): ?>
<div class="alert alert-success alert-dismissible fade show mb-3" role="alert">
    <?php echo e(session('success_message')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session('error_message')): ?>
<div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
    <?php echo e(session('error_message')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session('warning_message')): ?>
<div class="alert alert-warning alert-dismissible fade show mb-3" role="alert">
    <?php echo e(session('warning_message')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session('info_message')): ?>
<div class="alert alert-info alert-dismissible fade show mb-3" role="alert">
    <?php echo e(session('info_message')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session('light_message')): ?>
<div class="alert alert-light alert-dismissible fade show mb-3" role="alert">
    <?php echo e(session('light_message')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if(session('dark_message')): ?>
<div class="alert alert-dark alert-dismissible fade show mb-3" role="alert">
    <?php echo e(session('dark_message')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php /**PATH /var/www/html/coin_client/resources/views/includes/message.blade.php ENDPATH**/ ?>