<?php $__env->startSection('custom_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div id="wrap">
    <h2>Withdraw List</h2>
    <hr>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive mt-5 text-center">
                <table class="table" id="data-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Amount (USDT</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th style="min-width: 125px;">Action</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>

    
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>

<script type="text/javascript">
    $(function() {
        window.dataTable = $('#data-table').DataTable({
            processing: true,
            serverSide: true,
            order: [[ 4, "desc" ]],
            ajax: '<?php echo route("admin-withdraw-list-data"); ?>',
            columns: [
                { data: 'name', name: 'name' },
                { data: 'email', name: 'email' },
                { data: 'amount', name: 'amount' },
                { data: 'status', name: 'status' },
                { data: 'created_at', name: 'created_at' },
                { data: 'action', name: 'action', orderable: false, searchable: false }
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/coin_client/resources/views/admin/withdraw/index.blade.php ENDPATH**/ ?>