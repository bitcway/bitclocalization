<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <?php echo $__env->yieldContent('custom_css'); ?>

    <title><?php echo e(env('APP_NAME')); ?></title>
</head>
<body>
    
    <?php echo $__env->yieldContent('content'); ?>
    
    <footer>
        Best regards
        <br>
        OAS Team
    </footer>
    <?php echo $__env->yieldContent('custom_js'); ?>
</body>
</html><?php /**PATH /var/www/html/coin_client/resources/views/layouts/email.blade.php ENDPATH**/ ?>