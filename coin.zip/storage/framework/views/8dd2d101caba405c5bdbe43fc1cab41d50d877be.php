<?php $__env->startSection('custom_css'); ?>
    <style>
        .dynamic-content{
            display: none;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="wrap" class="deposit">
    <h3>DMGCoin Settings</h3>
    <hr>

    <div class="row">
        <div class="col-md-8 col-lg-6">
            <div class="card">
                <div class="card-body">
                    <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   <form action="" method="post">
                       <?php echo csrf_field(); ?>
                       <div class="form-group">
                           <label for="">Start Price</label>
                           <input type="number" step="any" class="form-control" name="start_price" placeholder="Enter start price..." value="<?php echo e($coin->start_price); ?>" required>
                           <?php $__errorArgs = ['start_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <small class="text-danger"><?php echo e($message); ?></small>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       </div>
                       <div class="form-group">
                           <label for="">Start Date</label>
                           <input type="date" class="form-control" name="start_date" placeholder="Enter start price..." value="<?php echo e($coin->start_date); ?>" required>
                           <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <small class="text-danger"><?php echo e($message); ?></small>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       </div>
                       <div class="form-group">
                           <label for="">End Date</label>
                           <input type="date" class="form-control" name="end_date" placeholder="Enter start price..." value="<?php echo e($coin->end_date); ?>" required>
                           <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <small class="text-danger"><?php echo e($message); ?></small>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       </div>
                       <div class="form-group">
                           <label for="">Price Update (%)</label>
                           <input type="number" step="any" class="form-control" name="price_update" placeholder="Enter start price..." value="<?php echo e($coin->price_update); ?>" required>
                           <?php $__errorArgs = ['price_update'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <small class="text-danger"><?php echo e($message); ?></small>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       </div>

                       <?php foreach ($periods as $key => $value) {?>
                            <div class="parent">
                                <hr>
                                <div class="form-group">
                                    <label for="">Start Date</label> <button type="button" class="btn btn-outline-danger float-end btn-sm remove">remove</button>
                                    <input type="date" class="form-control" name="pstart_date[]" value="<?php echo e($value->start_date); ?>" placeholder="Enter start price..." required>
                                </div>
                                <div class="form-group">
                                    <label for="">End Date</label>
                                    <input type="date" class="form-control" name="pend_date[]" value="<?php echo e($value->end_date); ?>" placeholder="Enter start price..." required>
                                </div>
                                <div class="form-group">
                                    <label for="">Price Update (%)</label>
                                    <input type="number" step="any" class="form-control" value="<?php echo e($value->price_update); ?>" name="pprice_update[]" placeholder="Enter start price..." required>
                                </div>
                            </div>
                       <?php }?>

                       <button type="button" class="btn btn-outline-success add">Add periodic price change</button>
                       <hr>
                       <button type="submit" class="btn btn-primary btn-block float-right">Update</button>

                   </form>

                    

                </div>
            </div>

        </div>
    </div>
</div>



<div class="dynamic-content">
    <div class="parent">
        <hr>
        <div class="form-group">
            <label for="">Start Date</label> <button type="button" class="btn btn-outline-danger float-end btn-sm remove">remove</button>
            <input type="date" class="form-control" name="pstart_date[]" placeholder="Enter start price..." required>
        </div>
        <div class="form-group">
            <label for="">End Date</label>
            <input type="date" class="form-control" name="pend_date[]" placeholder="Enter start price..." required>
        </div>
        <div class="form-group">
            <label for="">Price Update (%)</label>
            <input type="number" step="any" class="form-control" name="pprice_update[]" placeholder="Enter start price..." required>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
    <script>
        $(function(){
            $('.add').on('click', function(){
                let content = $('.dynamic-content').html();
                $(this).before(content);
            });
            $(document).on('click', '.remove', function(){
                console.log('working');
                console.log($(this).parents('.parent'));
                $(this).parents('.parent').remove();
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/coin_client/resources/views/admin/dmg_coin/index.blade.php ENDPATH**/ ?>