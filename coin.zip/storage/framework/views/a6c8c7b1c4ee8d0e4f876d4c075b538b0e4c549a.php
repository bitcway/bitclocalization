<?php $__env->startSection('custom_css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h3>Dear <?php echo e($data->first_name.' '.$data->last_name); ?>,</h3>
    <p>Please click bellow link to reset your password.</p>
    <p><a href="<?php echo e(route('reset-action', ['token' => $data->verification_token])); ?>">ACTIVATE</a></p>
    <p>Or copy the url provided bellow and paste to your browser address bar.</p>
    <p><?php echo e(route('reset-action', ['token' => $data->verification_token])); ?></p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/coin_client/resources/views/emails/reset_password.blade.php ENDPATH**/ ?>