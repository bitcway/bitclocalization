<!-- Site footer -->
<!-- Site footer -->


<hr>
<footer class="text-center pb-3">
    
    <div class="mb-2">
        <small>
            © 2020 made with <i class="fa fa-heart" style="color:red"></i> by - <a target="_blank"
                rel="noopener noreferrer" href="#">
                DMGCOIN
            </a>
        </small>
    </div>
    <div>
        <a href="#" target="_blank">
            <img alt="GitHub followers"
                src="https://img.shields.io/github/followers/azouaoui-med?label=github&style=social" />
        </a>
        <a href="#" target="_blank">
            <img alt="Twitter Follow"
                src="https://img.shields.io/twitter/follow/azouaoui_med?label=twitter&style=social" />
        </a>
    </div>
</footer>
<?php /**PATH /var/www/html/coin_client/resources/views/includes/footer.blade.php ENDPATH**/ ?>